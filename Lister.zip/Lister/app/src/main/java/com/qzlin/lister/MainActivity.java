package com.qzlin.lister;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    public reader list = new reader();
    public String lista;
    public String listb;
    public boolean listisload;
    public int id;
    public int idlen;
    //view
    //public final TextView ta = findViewById(R.id.texta);
    //public final TextView tb = findViewById(R.id.textb);
    //TextView ta = findViewById(R.id.texta);
    //TextView tb = findViewById(R.id.textb);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestAllPower();
    }

    public void requestAllPower() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            }
        }
    }

    public void sendmsg(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_SHORT).show();
    }

    public void sendmsgl(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_LONG).show();
    }


    @SuppressLint("SdCardPath")
    public void hide(View view){
        TextView ta = findViewById(R.id.texta);
        TextView tb = findViewById(R.id.textb);
        //list.writetext("/sdcard/lister/simple.list", "t");
        tb.setVisibility(View.INVISIBLE);
    }

    public void show(View view){
        TextView ta = findViewById(R.id.texta);
        TextView tb = findViewById(R.id.textb);
        tb.setVisibility(View.VISIBLE);
    }

    public void setview(View view) {
        setContentView(R.layout.set);
        sendmsg("设置");
    }

    public void editview(View view) {
        setContentView(R.layout.edit);
        sendmsg("编辑器");
    }

    public void back(View view) {
        setContentView(R.layout.activity_main);
        sendmsg("返回");
    }

    public void set_loadfile(View view) {
        id = 0;
        String filename;
        String readed;
        boolean ff;
        String sdcard = String.valueOf(Environment.getExternalStorageDirectory());
        //判断目录是否存在
        File f = new File(sdcard + "/lister/");
        ff = f.exists();
        if (!ff) {
            f.mkdir();
        }

        final EditText name = findViewById(R.id.set_filename);
        filename = String.valueOf(name.getText());

        if (filename.equals("")) {
            sendmsg("请输入文件名");
            return;
        }
        filename = sdcard + "/lister/" + filename + ".list";
        readed = list.readToString(filename);
        if (readed.equals("fn")) {
            sendmsg("错误，未找到文件：" + filename);
            return;
        }
        //处理数据
        int ia, ib, ea, eb;
        ia = readed.indexOf("@A") + 2;
        ea = readed.indexOf("@E", ia + 1);
        ib = readed.indexOf("@B", ea + 1) + 2;
        eb = readed.indexOf("@E", ib + 1);
        lista = readed.substring(ia, ea);
        listb = readed.substring(ib, eb);
        //
        listisload = true;
        //name.setText(lista + " " + listb);
        int i = 0;
        int ii = 0;
        while (lista.indexOf(";", i + 1) != -1) {
            i = lista.indexOf(";", i + 1);
            ii++;
        }
        idlen = ii;
        sendmsg("载入成功！");
    }

    public String getTextById(String string, int id) {
        String back = "";
        int a, b;
        int i;
        a = 0;
        for (i = 0; i <= id; i++) {
            //System.out.println(s.indexOf(";",i));
            b = a + 1;
            back = string.substring(a + 1, string.indexOf(";", b));
            a = string.indexOf(";", a + 1);
        }

        return back;
    }

    public void next(View view) {
        TextView ta = findViewById(R.id.texta);
        TextView tb = findViewById(R.id.textb);
        TextView t_id = findViewById(R.id.text_id);

        if (!listisload) {
            sendmsg("请先载入列表文件");
            return;
        }
        if (id >= idlen) {
            id = 0;
        }
        ta.setText(getTextById(lista, id));
        tb.setText(getTextById(listb, id));
        t_id.setText(String.valueOf(id));
        tb.setVisibility(View.INVISIBLE);
        id += 1;
    }

    public void load_by_id(View view){
        final TextView e_id = findViewById(R.id.edit_id);
        TextView ta = findViewById(R.id.texta);
        TextView tb = findViewById(R.id.textb);
        TextView t_id = findViewById(R.id.text_id);

        if (!listisload) {
            sendmsg("请先载入列表文件");
            return;
        }

        if(String.valueOf(e_id.getText()).equals("")){
            sendmsg("请输入ID");
            return;
        }
        id = Integer.parseInt(String.valueOf(e_id.getText()));

        if (id >= idlen) {
            id = 0;
        }
        ta.setText(getTextById(lista, id));
        tb.setText(getTextById(listb, id));
        t_id.setText(String.valueOf(id));
        tb.setVisibility(View.INVISIBLE);
    }

    public void editer_load(View view){
        String filename;
        String text;
        //get sdcard path

        //判断目录是否存在
        String sdcard = String.valueOf(Environment.getExternalStorageDirectory());
        File f = new File(sdcard + "/lister/");
        if (! f.exists()) {
            f.mkdir();//create folder
        }

        final EditText name = findViewById(R.id.edit_filename);
        filename = String.valueOf(name.getText());

        if (filename.equals("")) {
            sendmsg("请输入文件名");
            return;
        }

        filename = sdcard + "/lister/" + filename + ".list";

        File textf = new File(filename);
        if(! textf.exists()){
            try {
                textf.createNewFile();
                sendmsg("未找到文件,尝试创建新文件");
            }
            catch (IOException e){
                sendmsg("创建失败");
                return;
            }
        }

        text = list.readToString(filename);
        if (text.equals("fn")) {
            sendmsg("文件不存在：" + filename);
        }
        final EditText editor = findViewById(R.id.edit_editor);
        editor.setText(text);
        sendmsg("成功载入！");
    }

    public void editor_save(View view){
        String filename;
        String text;
        //get sdcard path

        //判断目录是否存在
        String sdcard = String.valueOf(Environment.getExternalStorageDirectory());
        File f = new File(sdcard + "/lister/");
        if (! f.exists()) {
            f.mkdir();//create folder
        }

        final EditText name = findViewById(R.id.edit_filename);
        filename = String.valueOf(name.getText());

        if (filename.equals("")) {
            sendmsg("请输入文件名");
            return;
        }

        filename = sdcard + "/lister/" + filename + ".list";

        File textf = new File(filename);
        if(! textf.exists()){
            try {
                textf.createNewFile();
                sendmsg("未找到文件,尝试创建新文件");
            }
            catch (IOException e){
                sendmsg("创建失败");
                return;
            }
        }
        EditText editor =  findViewById(R.id.edit_editor);
        try {
            list.writetext(filename,String.valueOf(editor.getText()));
            sendmsg("写入成功");
        } catch (IOException e) {
            sendmsg("写入失败");
        }
    }
}
