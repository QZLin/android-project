package com.qzlin.lister;

import java.io.*;

public class reader {

    int writetext(String filename, String string) throws IOException {
        int back = 1;
        //InputStream file = new FileInputStream(filename);
        try {
            File f = new File(filename);
            OutputStream ofile = new FileOutputStream(f);
            OutputStreamWriter writer = new OutputStreamWriter(ofile, "UTF-8");
            writer.append(string);
            writer.close();
        } catch (IOException e) {
            back = -1;
        }
        return back;
    }

    String readtext(String filename) {
        String back = "";
        try {
            InputStream file = new FileInputStream(filename);
            back = String.valueOf(file.read());
        } catch (IOException e) {
            back = "error";
        }
        return back;
    }

    String readToString(String fileName) {
        String encoding = "UTF-8";
        File file = new File(fileName);
        Long filelength = file.length();
        byte[] filecontent = new byte[filelength.intValue()];
        try {
            FileInputStream in = new FileInputStream(file);
            in.read(filecontent);
            in.close();
        } catch (FileNotFoundException e) {
            return "fn";
        } catch (IOException e) {
            return  "rf";
        }
        try {
            return new String(filecontent, encoding);
        } catch (UnsupportedEncodingException e) {
            return "ce";
        }
    }

    String readlist(String string, String listname){
        String back = "";
        
        return back;
    }
}
