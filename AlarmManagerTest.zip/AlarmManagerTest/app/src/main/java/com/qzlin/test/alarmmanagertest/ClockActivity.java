package com.qzlin.test.alarmmanagertest;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

public class ClockActivity extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.e("alarm","clock method");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new AlertDialog.Builder(ClockActivity.this).setTitle("闹钟").setMessage("小猪小猪快起床~")
                .setPositiveButton("关闭闹铃", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        ClockActivity.this.finish();
                    }
                }).show();
        Toast.makeText(getApplicationContext(), "alarm", Toast.LENGTH_LONG).show();
    }
}
