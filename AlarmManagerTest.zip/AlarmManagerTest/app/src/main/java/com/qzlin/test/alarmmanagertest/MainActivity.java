package com.qzlin.test.alarmmanagertest;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void setAlarm(View view) {
        alarm();
    }


    public void alarm() {
        Log.e("alarm", "alarm method");
        Intent intent = new Intent(MainActivity.this, AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, intent, 0);
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Calendar calendar = Calendar.getInstance();

        calendar.setTimeInMillis(System.currentTimeMillis());

        //calendar.set(Calendar.HOUR, Calendar.HOUR);
        //calendar.set(Calendar.MINUTE, Calendar.MINUTE);
        calendar.set(Calendar.SECOND, Calendar.SECOND + 5);
        calendar.set(Calendar.MILLISECOND, 0);

        Toast.makeText(getApplicationContext(), calendar.getTimeInMillis() + "", Toast.LENGTH_SHORT).show();

        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pi);

    }
}
